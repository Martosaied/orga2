/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#include "sched.h"

// Variables globales

info_entry info_array[20];

uint32_t score_a = 0;
uint32_t score_b = 0;

uint32_t fruit_quant = 13;

uint8_t debug_mode = 0;

// Mapa de fruta

uint16_t fruit_map[50][50];

uint16_t fruit_map[50][50] = {
	[0][12] = (uint16_t) 1,
	[10][14]= (uint16_t) 2,
	[43][10]= (uint16_t) 3,
	[2][0] = (uint16_t) 1,
	[5][11]= (uint16_t) 2,
	[33][48]= (uint16_t) 3,
	[15][19]= (uint16_t) 1,
	[21][36]= (uint16_t) 2,
	[12][25]= (uint16_t) 3,
	[14][7]= (uint16_t) 1,
	[23][34]= (uint16_t) 2,
	[18][23]= (uint16_t) 3,
	[3][3]= (uint16_t) 1,
};



void sched_init() {
	// inicia las estructuras del sched -arrays-
	// empiezan todas libres
	for (int i = 0; i < 20; ++i) {
		info_array[i].state = FREE_TASK;
	}
	// inicializo las primeras dos tareas A y B
	// tarea A0
	//breakpoint();
	info_array[0].state = TO_BE_EXECUTED;
	info_array[0].x = 0;
	info_array[0].y = 0;
	info_array[0].new_x = 0;
	info_array[0].new_y = 0;
	info_array[0].counter = 0;
	info_array[0].weight = 64;
	// tarea B0
	info_array[10].state = TO_BE_EXECUTED;
	info_array[10].x = 25;
	info_array[10].y = 25;
	info_array[10].new_x = 25;
	info_array[10].new_y = 25;
	info_array[10].counter = 0;
	info_array[10].weight = 64;
	// inicializo el indice global en 0
	INDEX_INFO = 0;
}


int16_t sched_nextTask() {
  	// tengo un indice actual y lo voy actualizando hasta q llego al final
	int i = 0;
	for (i = INDEX_INFO; i < 20 && info_array[i].state != TO_BE_EXECUTED ; ++i)	{}
  	if (i != 20) {
  		INDEX_INFO = i+1; 			// esto no se rompe cuando i = 19 porq en el proximo next task le tengo q decir q ya di la vuelta
  	} else {
  		INDEX_INFO = 0;
  	}
  	return i;			// decidimos devolver el indice de la info en vez del de la gdt porq nos pinto (faltaria sumarle 30)
}

uint16_t add_weight_a(uint32_t x, uint32_t y) {
		uint16_t res = 0;
		for (int i = 0; i < 10; i++) {
				if (info_array[i].x == x && info_array[i].y == y && info_array[i].state != FREE_TASK) {
					res += info_array[i].weight;
				}
		}
		return res;
}

uint16_t add_weight_b(uint32_t x, uint32_t y) {
		uint16_t res = 0;
		for (int i = 10; i < 20; i++) {
				if (info_array[i].x == x && info_array[i].y == y && info_array[i].state != FREE_TASK && info_array[i].state != FUTURE_FREE_TASK) {
					res += info_array[i].weight;
				}
		}
		return res;
}

void kill_task_a(uint32_t x, uint32_t y) {
		//breakpoint();
		for (int i = 0; i < 10; i++) {
				if (info_array[i].x == x && info_array[i].y == y) {
					info_array[i].state = FREE_TASK;
				}
		}
}

void kill_task_b(uint32_t x, uint32_t y) {
		for (int i = 10; i < 20; i++) {
				if (info_array[i].x == x && info_array[i].y == y) {
					info_array[i].state = FREE_TASK;
				}
		}
}

void fruit_refresh_a() {
		for (int i = 0; i < 10; i++) {
				if (info_array[i].state == TO_BE_EXECUTED) {
						if (fruit_map[info_array[i].x][info_array[i].y] == GRAPE) {
								score_a += GRAPE_POINTS;
								fruit_quant--;
						} else if (fruit_map[info_array[i].x][info_array[i].y] == BANANA) {
								score_a += BANANA_POINTS;
								fruit_quant--;
						} else if (fruit_map[info_array[i].x][info_array[i].y] == STRAWBERRY) {
								score_a += STRAWBERRY_POINTS;
								fruit_quant--;
						}
						fruit_map[info_array[i].x][info_array[i].y] = 0;
				}
		}
}

void fruit_refresh_b() {
		for (int i = 10; i < 20; i++) {
				if (info_array[i].state == TO_BE_EXECUTED) {
						if (fruit_map[info_array[i].x][info_array[i].y] == GRAPE) {
								score_b += GRAPE_POINTS;
								fruit_quant--;
						} else if (fruit_map[info_array[i].x][info_array[i].y] == BANANA) {
								score_b += BANANA_POINTS;
								fruit_quant--;
						} else if (fruit_map[info_array[i].x][info_array[i].y] == STRAWBERRY) {
								score_b += STRAWBERRY_POINTS;
								fruit_quant--;
						}
						fruit_map[info_array[i].x][info_array[i].y] = 0;
				}
		}
}

uint32_t nextTurn() {
		for (int i = 0; i < 20; i++) {
				info_array[i].x = info_array[i].new_x;
				info_array[i].y = info_array[i].new_y;
				info_array[i].counter = 0;
		}
		// buscamos colisiones
		for (int i = 0; i < 10; i++) {
				// busco, colisiones, si encuentro... calculo pesos de a y de b y vemos quien vive y quien muere
				if (info_array[i].state != FREE_TASK && info_array[i].state != FUTURE_FREE_TASK) {
						uint32_t weight_a = add_weight_a(info_array[i].x, info_array[i].y); 		// weight me da todos los pesos de
						uint32_t weight_b = add_weight_b(info_array[i].x, info_array[i].y); 		// a o b en esa posicion
						if (weight_b != 0) {
								// si pesan lo mismo mueren los dos
								if (weight_b == weight_a) {
										kill_task_a(info_array[i].x, info_array[i].y);
										kill_task_b(info_array[i].x, info_array[i].y);
								// si a pesa mas, lo come y gana puntos
								} else if (weight_b < weight_a) {
										kill_task_b(info_array[i].x, info_array[i].y);
										score_a += weight_b;
								// analogo
								} else {
										kill_task_a(info_array[i].x, info_array[i].y);
										score_b += weight_a;
								}
						}
				}
		}
		// actualizo estados de tareas nuevas o que fueron desalojadas
		for (int i = 0; i < 20; i++) {
				if (info_array[i].state == FUTURE_FREE_TASK) {
						info_array[i].state = FREE_TASK;
				} else if (info_array[i].state == FUTURE_TASK) {
						info_array[i].state = TO_BE_EXECUTED;
				}
		}
		// actualizo frutas a
		fruit_refresh_a();

		// actualizo frutas b
		fruit_refresh_b();

		//breakpoint();

		// nos fijamos fin del juego
		if (fruit_quant == 0)	return 1;

		int i = 0;
		while (i < 10 && info_array[i].state == FREE_TASK) {
				i++;
		}
		if (i == 10) return 1;

		i = 10;
		while (i < 20 && info_array[i].state == FREE_TASK) {
				i++;
		}
		if (i == 20) return 1;

		return 0;
}

void kill_actual_task(uint32_t index) {
	info_array[index].state = FUTURE_FREE_TASK;
}



// -------------------------------------------------------------------------------------------------

