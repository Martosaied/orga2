/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  Definicion de funciones  auxiliares de interrupciones

*/

#include "interrupts.h"

// Interrupción del teclado

void intKey(unsigned char value){
	char* printChar = "";
	switch(value){
		case 0x02:
		(printChar) = "1";
		break;

		case 0x03:
		(printChar) = "2";
		break;

		case 0x04:
		(printChar) = "3";
		break;

		case 0x05:
		(printChar) = "4";
		break;

		case 0x06:
		(printChar) = "5";
		break;

		case 0x07:
		(printChar) = "6";
		break;

		case 0x08:
		(printChar) = "7";
		break;

		case 0x09:
		(printChar) = "8";
		break;

		case 0x0a:
		(printChar) = "9";
		break;

		case 0x0b:
		(printChar) = "0";
		break;

		case 0x26:
		if (on_libretas == 0) {
			char *string = "36/17, 52/17, 311/17";
			print(string,49,50, keyboard_attr);
			on_libretas = 1;
		} else {
			char *string = "                    ";
			print(string,49,50, keyboard_attr);
			on_libretas = 0;
		}
		(printChar) = " ";
		break; 

		case 0x15:
		if (debug_mode == 1 || debug_mode == 2) {
			char *string = "          ";
			print(string,0,67, keyboard_attr);
			debug_mode = 0;
		} else {
			char *string = "MODO DEBUG";
			print(string,0,67, keyboard_attr);
			debug_mode = 1;
		}
		break;

		case 0x82:
		(printChar) = " ";
		break;

		case 0x83:
		(printChar) = " ";
		break;

		case 0x84:
		(printChar) = " ";
		break;

		case 0x85:
		(printChar) = " ";
		break;

		case 0x86:
		(printChar) = " ";
		break;

		case 0x87:
		(printChar) = " ";
		break;

		case 0x88:
		(printChar) = " ";
		break;

		case 0x89:
		(printChar) = " ";
		break;

		case 0x8a:
		(printChar) = " ";
		break;

		case 0x8b:
		(printChar) = " ";
		break;
	}
	print(printChar,79,0,keyboard_attr);
}

//---------------------------------------------------------------------------

// Syscalls

//Read

int calcularPosX(int offset, int x) {
	return (x+offset)%50;
}

int calcularPosY(int offset, int y) {
	return (y+offset)%50;
}

int abs(int x) {
	if (x<0) {
		return x*(-1);
	} else {
		return x;
	}
}

uint32_t read(int32_t x, int32_t y, uint32_t index) {
	if (info_array[index].counter >= info_array[index].weight) {
		// llamar a idle
		return 50;
	}
	info_array[index].counter += 1;
	if (info_array[index].weight < (abs(x) + abs(y))) {
		return 0;
	} else {
		int posX = calcularPosX(x,info_array[index].x);
		int posY = calcularPosY(y,info_array[index].y);
		for (int i = 0; i < 20; ++i) {				// recorro info array para ver si hay alguien ahi
			if (info_array[i].x == posX && info_array[i].y == posY) {
				if ( (index < 10 && i<10) || (index >= 10 && i >= 10) ){
					return 20;
				} else {
					return 30;
				}
			}
		}
		//  chequeo fruta , return 40
		if (fruit_map[posX][posY] != 0) {
			return 40;
		}
		return 10;
	}
}

// Move

uint32_t min (uint32_t a, uint32_t b) {
	if (a < b) {
		return a;
	} else {
		return b;
	}
}

uint32_t mod50 (int32_t val){
	if (val < 0) {
		while(val < 0) {
			val += 50;
		}
	} else {
		while(val >= 50) {
			val = val-50;
		}
	}
	return (uint32_t)val;
}

uint32_t move(uint32_t distance, uint32_t direction, uint32_t index) {

	uint32_t max_allowed = 	64 / info_array[index].weight;
	uint32_t effective_distance = min (max_allowed,distance);
	print_dec(direction,4,46,52,0x0f);
	print_dec(effective_distance,4,47,52,0x0f);

	if (direction == RIGHT) {		
		info_array[index].new_y = mod50(info_array[index].y + effective_distance);
		print_dec(mod50(info_array[index].y + effective_distance),4,48,52,0x0f);
	} else if (direction == LEFT) {
		info_array[index].new_y = mod50((int32_t)info_array[index].y - (int32_t)effective_distance);
		print_dec(mod50((int32_t)info_array[index].y - (int32_t)effective_distance), 4,48,52,0x0f);
	} else if (direction == DOWN) {
		info_array[index].new_x = mod50((int32_t)info_array[index].x + (int32_t)effective_distance);
		print_dec(mod50((int32_t)info_array[index].x + (int32_t)effective_distance),4,48,52,0x0f);
	} else if (direction == UP) {
		info_array[index].new_x = mod50((int32_t)info_array[index].x - (int32_t)effective_distance);
		print_dec(mod50((int32_t)info_array[index].x - (int32_t)effective_distance),4,48,52,0x0f);
	}

	return effective_distance;
}

// Divide

uint32_t divide(uint32_t cr3, uint32_t index, uint32_t return_copy, uint32_t flags, uint32_t esp) {
	if (info_array[index].weight == 1) {		// chequeo si no me puedo dividir más
		return -1;
	}

	info_array[index].weight = info_array[index].weight / 2;
	uint32_t offset_a_or_b = 0;			// sumo el offset a las tareas q voy a chequear en info array
	if (index >= 10) {					// si es b tengo q setearlo en 10
		offset_a_or_b = 10;
	}
	int i = 0;
	while (info_array[i+offset_a_or_b].state != FREE_TASK && i < 10) { ++i; }

	if (i == 10) {
		return -1;
	} else {
		tss_task_init(i+offset_a_or_b, cr3, i_am_task, return_copy, flags, esp);
		info_array[i+offset_a_or_b].state = FUTURE_TASK;
		info_array[i+offset_a_or_b].new_x = info_array[index].x;
		info_array[i+offset_a_or_b].new_y = info_array[index].y;
		info_array[i+offset_a_or_b].weight = info_array[index].weight;		
	}

	return 0;
}
