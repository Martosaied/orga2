/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de las rutinas de atencion de interrupciones
*/

#include "defines.h"
#include "idt.h"
#include "isr.h"
#include "tss.h"

#define attr_user 0xee00
#define attr_kernel 0x8e00

idt_entry idt[255] = { };

idt_descriptor IDT_DESC = {
    sizeof(idt) - 1,
    (uint32_t) &idt
};

/*
    La siguiente es una macro de EJEMPLO para ayudar a armar entradas de
    interrupciones. Para usar, descomentar y completar CORRECTAMENTE los
    atributos y el registro de segmento. Invocarla desde idt_inicializar() de
    la siguiene manera:

    void idt_inicializar() {
        IDT_ENTRY(0);
        ...
        IDT_ENTRY(19);
        ...
    }
*/

/*
#define IDT_ENTRY(numero)                                                                          \
    idt[numero].offset_0_15 = (uint16_t) ((uint32_t)(&_isr ## numero) & (uint32_t) 0xFFFF);        \
    idt[numero].segsel = (uint16_t) 0x00;                                                          \
    idt[numero].attr = (uint16_t) 0x0000;                                                          \
    idt[numero].offset_16_31 = (uint16_t) ((uint32_t)(&_isr ## numero) >> 16 & (uint32_t) 0xFFFF);
*/

#define idt_entry(numero, attrs)                                                                         \
    idt[numero].offset_0_15 = (uint16_t)((uint32_t)(&_isr ## numero) & (uint32_t) 0xFFFF);       \
    idt[numero].segsel = (uint16_t) 0xb0;                                                         \
    idt[numero].attr = (uint16_t) attrs;                                                         \
    idt[numero].offset_16_31 = (uint16_t) ((uint32_t)(&_isr ## numero) >> 16 & (uint32_t) 0xFFFF);

void idt_init() {
    idt_entry(0,attr_kernel);
    idt_entry(1,attr_kernel);
    idt_entry(2,attr_kernel);
    idt_entry(3,attr_kernel);
    idt_entry(4,attr_kernel);
    idt_entry(5,attr_kernel);
    idt_entry(6,attr_kernel);
    idt_entry(7,attr_kernel);
    idt_entry(8,attr_kernel);
    idt_entry(9,attr_kernel);
    idt_entry(10,attr_kernel);
    idt_entry(11,attr_kernel);
    idt_entry(12,attr_kernel);
    idt_entry(13,attr_kernel);
    idt_entry(14,attr_kernel);
    idt_entry(15,attr_kernel);    
    idt_entry(16,attr_kernel);
    idt_entry(17,attr_kernel);
    idt_entry(18,attr_kernel);
    idt_entry(19,attr_kernel);
    idt_entry(32,attr_kernel);
    idt_entry(33,attr_kernel);
    idt_entry(71,attr_user);
    idt_entry(73,attr_user);
    idt_entry(76,attr_user);
}


