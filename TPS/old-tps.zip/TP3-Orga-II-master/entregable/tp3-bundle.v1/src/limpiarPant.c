/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
*/
#define grey 0x7000
#define black 0x0000
#define yellow 0xee00
#define white 0xf000
#define grapey 0x7505
#define strawbeerie 0x740f
#define bananananabatman 0x7e29
#include "sched.h"
#include "screen.h"


void limpiarPant(short (*pantalla)[50][80]);

void fruit_refresh(short (*pantalla)[50][80]) {
		for (int i = 0; i < 50; i++) {
				for (int j = 0; j < 50; j++) {
						if (fruit_map[i][j] == GRAPE) {
								(*pantalla)[i][j] = grapey;
						} else if (fruit_map[i][j] == STRAWBERRY) {
								(*pantalla)[i][j] = strawbeerie;
						} else if (fruit_map[i][j] == BANANA) {
								(*pantalla)[i][j] = bananananabatman;
						}
				}
		}
}

void player_refresh() {
		// Player A
		for (int i = 0; i < 10; i++) {
				if (info_array[i].state == TO_BE_EXECUTED) {
						print_dec(i, 1, info_array[i].x, info_array[i].y, 0x4F);
				}
		}
		// Player B
		for (int i = 10; i < 20; i++) {
				if (info_array[i].state == TO_BE_EXECUTED) {
						print_dec(i-10, 1, info_array[i].x, info_array[i].y, 0x1F);
				}
		}
}

void scores_refresh(short (*pantalla)[50][80]) {
		print_dec(score_a, 10, 6, 59, 0x4F);				// printeo puntaje a
		print_dec(score_b, 10, 27, 59, 0x1F);				// printeo puntaje b

		// IMPRIMO TAREAS A
		for (int i = 0; i < 10; i++) {
				if (info_array[i].state == TO_BE_EXECUTED) {
						if (info_array[i].weight == 1) {
								print_dec(0, 1, 13, 54 + 2*i, 0x0F);
						} else if (info_array[i].weight == 2) {
								print_dec(1, 1, 13, 54 + 2*i, 0x0F);
						} else if (info_array[i].weight == 4) {
								print_dec(2, 1, 13, 54 + 2*i, 0x0F);
						} else if (info_array[i].weight == 8) {
								print_dec(3, 1, 13, 54 + 2*i, 0x0F);
						} else if (info_array[i].weight == 16) {
								print_dec(4, 1, 13, 54 + 2*i, 0x0F);
						} else if (info_array[i].weight == 32) {
								print_dec(5, 1, 13, 54 + 2*i, 0x0F);
						} else if (info_array[i].weight == 64) {
								print_dec(6, 1, 13, 54 + 2*i, 0x0F);
						}
				} else if (info_array[i].state == FREE_TASK) {
						print("X", 13, 54+2*i, 0x04);
				}
		}

		// IMPRIMO TAREAS B
		for (int i = 0; i < 10; i++) {
				if (info_array[i+10].state == TO_BE_EXECUTED) {
						if (info_array[i+10].weight == 1) {
								print_dec(0, 1, 34, 54 + 2*i, 0x0F);
						} else if (info_array[i+10].weight == 2) {
								print_dec(1, 1, 34, 54 + 2*i, 0x0F);
						} else if (info_array[i+10].weight == 4) {
								print_dec(2, 1, 34, 54 + 2*i, 0x0F);
						} else if (info_array[i+10].weight == 8) {
								print_dec(3, 1, 34, 54 + 2*i, 0x0F);
						} else if (info_array[i+10].weight == 16) {
								print_dec(4, 1, 34, 54 + 2*i, 0x0F);
						} else if (info_array[i+10].weight == 32) {
								print_dec(5, 1, 34, 54 + 2*i, 0x0F);
						} else if (info_array[i+10].weight == 64) {
								print_dec(6, 1, 34, 54 + 2*i, 0x0F);
						}
				} else if (info_array[i+10].state == FREE_TASK) {
						print("X", 34, 54+2*i, 0x01);
				}
		}

}

void screen_refresh(short (*pantalla)[50][80]) {
		limpiarPant(pantalla);
		fruit_refresh(pantalla);
		player_refresh(pantalla);
		scores_refresh(pantalla);
		if (debug_mode == 1) {
			print("MODO DEBUG",0,67, keyboard_attr);
		}
		if (on_libretas == 1) {
			print("36/17, 52/17, 311/17",49,50, keyboard_attr);
		}

}

void debug_print(uint32_t cr0, uint32_t cr2, uint32_t cr3, uint32_t cr4,
 				 uint16_t cs, uint16_t ds, uint16_t es, uint16_t fs, uint16_t gs, uint16_t ss, 
 				 uint32_t edi, uint32_t esi, uint32_t ebp, uint32_t esp0, uint32_t ebx, uint32_t edx, uint32_t ecx, uint32_t eax,
				 uint32_t eip, uint32_t cs3, uint32_t eflags, uint32_t esp, uint32_t ss3) {

	// hacer recuadro
	print("                               ", 3, 9, 0x00);
	print("                              ", 4, 9, 0x70);
	print(" eax                          ", 5, 9, 0x70);
	print("               cr0            ", 6, 9, 0x70);
	print(" ebx                          ", 7, 9, 0x70);
	print("               cr2            ", 8, 9, 0x70);
	print(" ecx                          ", 9, 9, 0x70);
	print("               cr3            ", 10, 9, 0x70);
	print(" edx                          ", 11, 9, 0x70);
	print("               cr4            ", 12, 9, 0x70);
	print(" esi                          ", 13, 9, 0x70);
	print("                              ", 14, 9, 0x70);
	print(" edi                          ", 15, 9, 0x70);
	print("                              ", 16, 9, 0x70);
	print(" ebp                          ", 17, 9, 0x70);
	print("                              ", 18, 9, 0x70);
	print(" esp                          ", 19, 9, 0x70);
	print("                              ", 20, 9, 0x70);
	print(" eip                          ", 21, 9, 0x70);
	print("                              ", 22, 9, 0x70);
	print("  cs           stack          ", 23, 9, 0x70);
	print("                              ", 24, 9, 0x70);
	print("  ds                          ", 25, 9, 0x70);
	print("                              ", 26, 9, 0x70);
	print("  es                          ", 27, 9, 0x70);
	print("                              ", 28, 9, 0x70);
	print("  fs                          ", 29, 9, 0x70);
	print("                              ", 30, 9, 0x70);
	print("  gs                          ", 31, 9, 0x70);
	print("                              ", 32, 9, 0x70);
	print("  ss                          ", 33, 9, 0x70);
	print("                              ", 34, 9, 0x70);
	print("                              ", 35, 9, 0x70);
	print("  eflags                      ", 36, 9, 0x70);
	print("                              ", 37, 9, 0x70);
	print("                              ", 38, 9, 0x0f);
	print(" ----PRESS 'Y' TO CONTINUE----", 40, 9, 0x7F);
	// bordes negros
	for (int i = 3; i < 39; ++i) {
		print(" ", i, 8, 0x00);
		print(" ", i, 39, 0x00); 
	}
	
	uint32_t *stack = (uint32_t*) esp0;

	// imprimir registros y pila
	print_hex(eax, 8, 5, 14, 0x7f);        print_hex(cr0, 8, 6, 28, 0x71);
	print_hex(ebx, 8, 7, 14, 0x7f);        print_hex(cr2, 8, 8, 28, 0x71);				
	print_hex(ecx, 8, 9, 14, 0x7f);        print_hex(cr3, 8, 10, 28, 0x71);
	print_hex(edx, 8, 11, 14, 0x7f);       print_hex(cr4, 8, 12, 28, 0x71);
	print_hex(esi, 8, 13, 14, 0x7f);
	print_hex(edi, 8, 15, 14, 0x7f);
	print_hex(ebp, 8, 17, 14, 0x7f);
	print_hex(esp0, 8, 19, 14, 0x7f);
	print_hex(eip, 8, 21, 14, 0x7f);
	print_hex(cs, 4, 23, 14, 0x7f);        print_hex((uint32_t)(*stack), 8, 26, 24, 0x7f);
	print_hex(ds, 4, 25, 14, 0x7f);        print_hex((uint32_t)(*(stack+4)), 8, 27, 24, 0x7f);
	print_hex(es, 4, 27, 14, 0x7f);        print_hex((uint32_t)(*(stack+8)), 8, 28, 24, 0x7f);
	print_hex(fs, 4, 29, 14, 0x7f);        print_hex((uint32_t)(*(stack+12)), 8, 29, 24, 0x7f);
	print_hex(gs, 4, 31, 14, 0x7f);        
	print_hex(ss, 4, 33, 14, 0x7f);

	print_hex(eflags, 8, 36, 18, 0x7f);

}

void limpiarPant(short (*pantalla)[50][80]) {
		// Limpio pantalla principal
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < 50; j++) {
				(*pantalla)[i][j] = 0x7000;
			}
		}
		// Limpio pantalla jugadores
		for (int k = 0; k < 50; k++) {
			for (int l = 50; l < 80; l++) {
				(*pantalla)[k][l] = 0x0000;
			}
		}
		// Pongo barras de jugadores
		// Jugador A
		for (int m = 5; m < 8; m++) {
			for (int n = 58; n < 70; n++) {
				(*pantalla)[m][n] = 0x4f00;
			}
		}
		// Jugador B
		for (int a = 26; a < 29; a++) {
			for (int b = 58; b < 70; b++) {
				(*pantalla)[a][b] = 0x1f00;
			}
		}
		// Pongo tareas A y B
		for (int i = 0; i < 10; i++) {
				print_dec(i, 1, 11, 54+2*i, 0x0F);
				print_dec(i, 1, 32, 54+2*i, 0x0F);
		}				
}


void game_over_bitch() {
	print("GAME OVER",23 , 20, 0x70);
	if(score_a < score_b) {
		print("BLUE WINS, RED SUCKS", 25, 15, 0X70);
	} else if (score_a == score_b) {
		print("NO WINNERS, SUCKERS", 25, 15, 0X70);
	} else {
		print("RED WINS, BLUE SUCKS", 25, 15, 0X70);
	}
}

