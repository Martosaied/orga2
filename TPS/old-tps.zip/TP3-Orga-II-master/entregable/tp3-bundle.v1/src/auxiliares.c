/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de estructuras para administrar tareas
*/

#include "auxiliares.h"


// Variables globales

unsigned int on_libretas;

void prints(char (*pantalla)[50][160], char* txt, int length){
	// Limpio pantalla principal
	for (int i = 0; i < 50; i++) {
		for (int j = 0; j < 80; j++) {
			(*pantalla)[i][j*2] = 0x03;
			(*pantalla)[i][j*2+1] = 0x04;
		}
	}
	// Copio string
	for (int j = 0; j < length; j++) {
			(*pantalla)[0][j*2] = *(txt+j);
			(*pantalla)[0][j*2+1] = 0x03;
		}
}

void libretas_init() {
	on_libretas = 0;
}
