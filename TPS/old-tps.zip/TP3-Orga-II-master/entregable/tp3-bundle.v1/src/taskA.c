/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
*/
#include "syscall.h" 
#include "game.h"

#define rightt 1
#define leftt 2
#define upp 3
#define downn 4 


int32_t read(int32_t x,int32_t y); 
//    return syscall_read(y,x);
//}

void task() {
/*
    int arriba = 0;
    int abajo = 0;
    //arriba
    if(read() == 40) {
        arriba ++;
    } */

    int32_t div0 = syscall_divide();
    int32_t div1 = syscall_divide();
    int32_t div2 = syscall_divide();

    int32_t numTask = 4*div0 + 2*div1 + 1*div2;

    
    int32_t width = 0;

    if (numTask != 0) {
        syscall_move(numTask, downn);
    }

    while(1) {
        width = 0;
        while(width<50) {
            int32_t foundFruit = 0;
            int32_t i;
            int32_t enemyClose = 0;
            for (i = 0; i < 8 ; ++i) {
                int32_t snoop = read(i+1, 0);
                                                                                   /////chequear enemigos posteriores a la fruta
                if(snoop == 30) {
                    enemyClose = i+1;
                } else if(snoop == 40 && foundFruit == 0) {
                    foundFruit = i+1;
                }                                                                 ////si estoy yo bajo un escalon
            }
            if(foundFruit != 0 && enemyClose == 0) {
                syscall_move(foundFruit, rightt);
                width += foundFruit;
            } else if(enemyClose == 8) {
                syscall_move(7, rightt);
                width += 7;
            } else {
                syscall_move(8, rightt);
                width += 8;
            }
            breakpoint();
        }
        syscall_move(8, downn);
    }
    //Null=0, None=10, Player=20, Opponent=30 y Food=40
}



int32_t read(int32_t x,int32_t y) { 
    return syscall_read(y,x);
}