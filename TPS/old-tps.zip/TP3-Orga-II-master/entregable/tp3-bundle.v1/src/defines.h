/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================

    Definiciones globales del sistema.
*/

#ifndef __DEFINES_H__
#define __DEFINES_H__

/* Video */
/* -------------------------------------------------------------------------- */
#define keyboard_attr 0x0f


/* Bool */
/* -------------------------------------------------------------------------- */
#define TRUE                    0x00000001
#define FALSE                   0x00000000
#define ERROR                   1
#define NULL                    0

/* Atributos paginas */
/* -------------------------------------------------------------------------- */
#define PAG_P                   0x00000001
#define PAG_R                   0x00000000
#define PAG_RW                  0x00000002
#define PAG_S                   0x00000000
#define PAG_US                  0x00000004


/* Misc */
/* -------------------------------------------------------------------------- */
#define SIZE_N                  50
#define SIZE_M                  50

/* Indices en la gdt */
/* -------------------------------------------------------------------------- */
#define GDT_COUNT 50

#define GDT_IDX_NULL_DESC           0
#define GDT_IDX_CODE0_DESC          22
#define GDT_IDX_CODE3_DESC          23
#define GDT_IDX_DATA0_DESC          24
#define GDT_IDX_DATA3_DESC          25
#define GDT_IDX_STACK_DESC          26
#define GDT_IDX_VIDEO_DESC          27
#define GDT_IDX_INIT_DESC           28
#define GDT_IDX_IDLE_DESC           29
#define GDT_IDX_TASKA_0_DESC        30
#define GDT_IDX_TASKA_1_DESC        31
#define GDT_IDX_TASKA_2_DESC        32
#define GDT_IDX_TASKA_3_DESC        33
#define GDT_IDX_TASKA_4_DESC        34
#define GDT_IDX_TASKA_5_DESC        35
#define GDT_IDX_TASKA_6_DESC        36
#define GDT_IDX_TASKA_7_DESC        37
#define GDT_IDX_TASKA_8_DESC        38
#define GDT_IDX_TASKA_9_DESC   	    39
#define GDT_IDX_TASKB_0_DESC        40
#define GDT_IDX_TASKB_1_DESC        41
#define GDT_IDX_TASKB_2_DESC        42
#define GDT_IDX_TASKB_3_DESC        43
#define GDT_IDX_TASKB_4_DESC        44
#define GDT_IDX_TASKB_5_DESC        45
#define GDT_IDX_TASKB_6_DESC        46
#define GDT_IDX_TASKB_7_DESC        47
#define GDT_IDX_TASKB_8_DESC        48
#define GDT_IDX_TASKB_9_DESC        49


/* Offsets en la gdt */
/* -------------------------------------------------------------------------- */
#define GDT_OFF_NULL_DESC           (GDT_IDX_NULL_DESC     << 3)
#define GDT_OFF_CODE0_DESC          (GDT_IDX_CODE0_DESC    << 3)
#define GDT_OFF_CODE3_DESC			(GDT_IDX_CODE3_DESC    << 3)
#define GDT_OFF_DATA0_DESC			(GDT_IDX_DATA0_DESC    << 3)
#define GDT_OFF_DATA3_DESC			(GDT_IDX_DATA3_DESC    << 3)
#define GDT_OFF_STACK_DESC          (GDT_IDX_STACK_DESC    << 3)
#define GDT_OFF_VIDEO_DESC          (GDT_IDX_VIDEO_DESC    << 3)
#define GDT_OFF_INIT_DESC           (GDT_IDX_INIT_DESC     << 3)
#define GDT_OFF_IDLE_DESC           (GDT_IDX_IDLE_DESC     << 3)
#define GDT_OFF_TASKA_0_DESC        (GDT_IDX_TASKA_0_DESC  << 3)
#define GDT_OFF_TASKA_1_DESC        (GDT_IDX_TASKA_1_DESC  << 3)
#define GDT_OFF_TASKA_2_DESC        (GDT_IDX_TASKA_2_DESC  << 3)
#define GDT_OFF_TASKA_3_DESC        (GDT_IDX_TASKA_3_DESC  << 3)
#define GDT_OFF_TASKA_4_DESC        (GDT_IDX_TASKA_4_DESC  << 3)
#define GDT_OFF_TASKA_5_DESC        (GDT_IDX_TASKA_5_DESC  << 3)
#define GDT_OFF_TASKA_6_DESC        (GDT_IDX_TASKA_6_DESC  << 3)
#define GDT_OFF_TASKA_7_DESC        (GDT_IDX_TASKA_7_DESC  << 3)
#define GDT_OFF_TASKA_8_DESC        (GDT_IDX_TASKA_8_DESC  << 3)
#define GDT_OFF_TASKA_9_DESC        (GDT_IDX_TASKA_9_DESC  << 3)
#define GDT_OFF_TASKB_0_DESC        (GDT_IDX_TASKB_0_DESC  << 3)
#define GDT_OFF_TASKB_1_DESC        (GDT_IDX_TASKB_1_DESC  << 3)
#define GDT_OFF_TASKB_2_DESC        (GDT_IDX_TASKB_2_DESC  << 3)
#define GDT_OFF_TASKB_3_DESC        (GDT_IDX_TASKB_3_DESC  << 3)
#define GDT_OFF_TASKB_4_DESC        (GDT_IDX_TASKB_4_DESC  << 3)
#define GDT_OFF_TASKB_5_DESC        (GDT_IDX_TASKB_5_DESC  << 3)
#define GDT_OFF_TASKB_6_DESC        (GDT_IDX_TASKB_6_DESC  << 3)
#define GDT_OFF_TASKB_7_DESC        (GDT_IDX_TASKB_7_DESC  << 3)
#define GDT_OFF_TASKB_8_DESC        (GDT_IDX_TASKB_8_DESC  << 3)
#define GDT_OFF_TASKB_9_DESC        (GDT_IDX_TASKB_9_DESC  << 3)


/* Selectores de segmentos */
/* -------------------------------------------------------------------------- */

/* Direcciones de memoria */
/* -------------------------------------------------------------------------- */
#define BOOTSECTOR               0x00001000 /* direccion fisica de comienzo del bootsector (copiado) */
#define KERNEL                   0x00001200 /* direccion fisica de comienzo del kernel */
#define VIDEO                    0x000B8000 /* direccion fisica del buffer de video */

/* Direcciones virtuales de código, pila y datos */
/* -------------------------------------------------------------------------- */
#define TASK_CODE             0x08000000 /* direccion virtual del codigo */
#define OFF_STACK_SIZE        0x00000fff /* direccion base del stack */
#define PAGE_SIZE 			  0X1000

/* Direcciones fisicas de codigos */
/* -------------------------------------------------------------------------- */
#define CODE_TASK_A 0x10000
#define CODE_TASK_B 0x12000

/* En estas direcciones estan los códigos de todas las tareas. De aqui se
 * copiaran al destino indicado por TASK_<i>_CODE_ADDR.
 */
#define TASK_IDLE_CODE_SRC_ADDR  0x00014000

/* Direcciones fisicas de directorios y tablas de paginas del KERNEL */
/* -------------------------------------------------------------------------- */
#define KERNEL_PAGE_DIR          0x00027000
#define KERNEL_PAGE_TABLE_0      0x00028000
#define PAGES_KERNEL_INITIAL_D	 0x00100000
#define PAGES_TASKS_INITIAL_D	 0x00400000
#define VIRTUAL_M_TASK_1		 0x08000000
#define VIRTUAL_M_TASK_2		 0x08001000
#define ATTR_TASK_PAGE			 0x00000007

/* TSS */
/* -------------------------------------------------------------------------- */
#define TSS_SIZE 104
#define i_am_task 1

/* SCHED */
/* -------------------------------------------------------------------------- */
#define FREE_TASK 0
#define FUTURE_TASK 1
#define TO_BE_EXECUTED 2
#define FUTURE_FREE_TASK 3

#define RIGHT 1
#define LEFT 2
#define UP 3
#define DOWN 4

#define GRAPE 1
#define BANANA 2
#define STRAWBERRY 3

#define GRAPE_POINTS 16
#define BANANA_POINTS 32
#define STRAWBERRY_POINTS 64

#endif  /* !__DEFINES_H__ */
