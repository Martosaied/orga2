/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  Definicion de funciones auxiliares de interrupciones
*/


#ifndef __INTERRUPTS_H__
#define __INTERRUPTS_H__

#include "defines.h"
#include "auxiliares.h"
#include "sched.h"

// Interrupcion del teclado
void intKey(unsigned char value);

// Syscalls
uint32_t read(int32_t x, int32_t y, uint32_t index);
uint32_t move(uint32_t distance, uint32_t direction, uint32_t index);
uint32_t divide(uint32_t cr3, uint32_t index, uint32_t return_copy, uint32_t flags, uint32_t esp);

#endif	/* !__INTERRUPTS_H__ */