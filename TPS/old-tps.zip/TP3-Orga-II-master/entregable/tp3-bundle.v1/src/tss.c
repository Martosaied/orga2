/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de estructuras para administrar tareas
*/

#include "tss.h"

tss tss_initial;
tss tss_idle;
tss tss_array[20];

void tss_idle_init(uint32_t cr3) {
	tss_idle.esp = 0x27000;
	tss_idle.ebp = 0x27000;
	tss_idle.eip = 0x14000;
	tss_idle.cs = 0xb0;
	tss_idle.ss = 0xd0;
	tss_idle.ds = 0xc0;
	tss_idle.es = 0xc0;
	tss_idle.gs = 0xc0;
	tss_idle.fs = 0xd8;
	tss_idle.eflags = 0x00000202;
	tss_idle.dtrap = 0x00;
	tss_idle.cr3 = cr3;
	tss_idle.iomap = 0xffff; 
	tss_idle.esp0 = 0x27000; 
	tss_idle.ss0 = 0xd0; 

}
  
void tss_init() {
	tss_initial.dtrap = 0x00; 
	//Actualizo bases de los selectores de tss en la gdt
	gdt[GDT_IDX_INIT_DESC].base_0_15  = (uint16_t)((uint32_t)(&tss_initial));         
	gdt[GDT_IDX_INIT_DESC].base_23_16 = (uint8_t)((uint32_t)(&tss_initial) >> 16);
	gdt[GDT_IDX_INIT_DESC].base_31_24 = (uint8_t)((uint32_t)(&tss_initial) >> 24);
	gdt[GDT_IDX_IDLE_DESC].base_0_15  = (uint16_t)((uint32_t)(&tss_idle));     
	gdt[GDT_IDX_IDLE_DESC].base_23_16 = (uint8_t)((uint32_t)(&tss_idle) >> 16);
	gdt[GDT_IDX_IDLE_DESC].base_31_24 = (uint8_t)((uint32_t)(&tss_idle) >> 24);
	// cambio en la gdt la base de la tss para todos los valores de las tasks
	for(int index = 0; index < 20; index++) {
		gdt[index+30].base_0_15  = (uint16_t)((uint32_t)(&tss_array)+ index*TSS_SIZE);         
		gdt[index+30].base_23_16 = (uint8_t)(((uint32_t)(&tss_array)+ index*TSS_SIZE) >> 16);
		gdt[index+30].base_31_24 = (uint8_t)(((uint32_t)(&tss_array)+ index*TSS_SIZE) >> 24);
	}
}

void tss_task_init(uint32_t index, uint32_t cr3, uint32_t kernel_or_task, uint32_t return_copy, uint32_t flags, uint32_t esp) {
	uint32_t cr3_new = mmu_initTaskDir(index, cr3, kernel_or_task);		// mapeo el codigo de la tarea y obtengo el cr3 q va a la tss
	
	uint32_t new_page = mmu_nextFreeKernelPage();		// pido una pagina para la pila del kernel

	if(kernel_or_task == 0) {
		tss_array[index].esp0 = new_page + 0x1000 ;
		tss_array[index].esp = 0x08002000;
		tss_array[index].ebp = 0x08002000;
		tss_array[index].eip = 0x08000000;
		tss_array[index].cs = 0xbb;
		tss_array[index].ss = 0xcb;
		tss_array[index].eflags = 0x00000202;
	
	} else {
		// copio pila del kernel
		uint32_t* src = (uint32_t*) ((esp>>12)<<12);			// limpio el offset del ebp para obtener la pagina de la pila del kernel ant
		uint32_t* dst = (uint32_t*) new_page;				// el destino es la pagina q me pedi para la pila del kernel

		for (uint32_t i = 0; i < PAGE_SIZE/4; ++i){			// copio de una pila a otra
			*(dst+i)=*(src+i);
		}

		tss_array[index].esp0 = ((esp<<20)>>20) + new_page;
		tss_array[index].esp = ((esp<<20)>>20) + new_page;
		//tss_array[index].ebp = ebp;
		tss_array[index].eip = return_copy;				// quiero volver a la int del reloj sabiendo q soy copia 
		tss_array[index].cs = 0xb0;
		tss_array[index].ss = 0xc0;
		tss_array[index].eflags = flags;		//???????????????????????????????????????????
	}
	
	tss_array[index].ds = 0xcb;
	tss_array[index].es = 0xcb;
	tss_array[index].gs = 0xcb;
	tss_array[index].fs = 0xcb;					// we don't use it so there's shit there
	tss_array[index].cr3 = cr3_new;
	tss_array[index].ss0 = 0xc0;
	tss_array[index].dtrap = 0x00;
	tss_array[index].iomap = 0xffff;
}


