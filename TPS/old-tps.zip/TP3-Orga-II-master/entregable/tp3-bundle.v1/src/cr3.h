/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================

Defino array de cr3 tareas */

uint32_t *cr3_tasksA;
uint32_t *cr3_tasksB;