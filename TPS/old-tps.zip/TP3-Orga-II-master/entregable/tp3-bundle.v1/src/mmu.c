/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del manejador de memoria
*/

#include "mmu.h"

unsigned int next_free_page_kernel;
unsigned int next_free_page_task;



void mmu_init() {
	next_free_page_kernel = PAGES_KERNEL_INITIAL_D;
	next_free_page_task = PAGES_TASKS_INITIAL_D;
}

uint32_t mmu_nextFreeKernelPage() {
    uint32_t res = next_free_page_kernel;
    next_free_page_kernel += 0x1000;
    return res;
}

uint32_t mmu_nextFreeTaskPage() {
    uint32_t res = next_free_page_task;
    next_free_page_task += 0x1000;
    return res;
}

void mmu_mapPage(uint32_t virtual, uint32_t cr3, uint32_t phy, uint32_t attrs) {  // en atributos le damos bola a los ultimos dos bits nomas -us y rw-
	uint32_t dir_index = (virtual>>22);
	uint32_t table_index = ((virtual<<10)>>22);	
	dt_entry *dir_table = (dt_entry*) ((cr3>>12)<<12);   // seteamos la base del directorio usando el cr3 por parametro
	if (dir_table[dir_index].p == 0) {					// si no está presente la tabla tengo que crearla
		uint32_t new_table_position = mmu_nextFreeKernelPage();
		pt_entry *new_table =(pt_entry*) new_table_position;
		dir_table[dir_index].p = 1;
		dir_table[dir_index].rw = 1;
		dir_table[dir_index].us = 1;
		dir_table[dir_index].pwt = 0;
		dir_table[dir_index].pcd = 0;
		dir_table[dir_index].a = 0;
		dir_table[dir_index].ign = 0;
		dir_table[dir_index].ps = 0;
		dir_table[dir_index].g = 0;
		dir_table[dir_index].avl = 0;
		dir_table[dir_index].base = (new_table_position >> 12);
		for (int i = 0; i < 1024; ++i) {		// pongo todos los valores de la nueva tabla como no presentes
			new_table[i].p = 0;			
		}		
	}
	
	uint32_t attr_us = ((attrs<<30)>>31);
	uint32_t attr_rw = ((attrs<<31)>>31);

	pt_entry *page_table = (pt_entry*)(((uint32_t)((dir_table[dir_index].base)))<<12);	
	page_table[table_index].p = 1;
	page_table[table_index].rw = attr_rw;
	page_table[table_index].us = attr_us;
	page_table[table_index].pwt = 0;				//el resto de los atributos siempre esta en 0 así que lo tomamos como fijo (!!)
	page_table[table_index].pcd = 0;
	page_table[table_index].a = 0;
	page_table[table_index].d = 0;
	page_table[table_index].pat = 0;
	page_table[table_index].g = 0;
	page_table[table_index].avl = 0;
	page_table[table_index].base = (phy>>12);

	tlbflush();
}

uint32_t mmu_unmapPage(uint32_t virtual, uint32_t cr3) {
    uint32_t dir_index = (virtual>>22);
	uint32_t table_index = ((virtual<<10)>>22);	
	dt_entry *dir_table = (dt_entry*) ((cr3>>12)<<12);   // seteamos la base del directorio usando el cr3 por parametro
	if (dir_table[dir_index].p == 0) {		
    	return 1;
    } else {
    	pt_entry *page_table = (pt_entry*) (((uint32_t)dir_table[dir_index].base)<<12);
    	page_table[table_index].p = 0;
    	tlbflush();
    	return 0;
    }
}

uint32_t mmu_initKernelDir() {
	dt_entry *dir_table = (dt_entry*) KERNEL_PAGE_DIR;
	dir_table[0].p = 1;
	dir_table[0].rw = 1;
	dir_table[0].us = 0;
	dir_table[0].pwt = 0;
	dir_table[0].pcd = 0;
	dir_table[0].a = 0;
	dir_table[0].ign = 0;
	dir_table[0].ps = 0;
	dir_table[0].g = 0;
	dir_table[0].avl = 0;
	dir_table[0].base = (KERNEL_PAGE_TABLE_0 >> 12);	

	for (int i = 1; i < 1024; ++i) {
		dir_table[i].p = 0;	
	}

	pt_entry *pt = (pt_entry*) (KERNEL_PAGE_TABLE_0);
	for (int i = 0; i < 1024; ++i) {
		pt[i].p = 1;
		pt[i].rw = 1;
		pt[i].us = 0;
		pt[i].pwt = 0;
		pt[i].pcd = 0;
		pt[i].a = 0;
		pt[i].d = 0;
		pt[i].pat = 0;
		pt[i].g = 0;
		pt[i].avl = 0;
		pt[i].base = i;
	}

    return 0;  
}

uint32_t mmu_initTaskDir(uint32_t index_task, uint32_t cr3, uint32_t kernel_or_task) {			// kernel_or_task : si es 0 es kernel si es 1 es task 
	dt_entry *new_directory = (dt_entry*) mmu_nextFreeKernelPage(); //ceros

	new_directory[0].p = 1;
	new_directory[0].rw = 1;
	new_directory[0].us = 0;
	new_directory[0].pwt = 0;
	new_directory[0].pcd = 0;
	new_directory[0].a = 0;
	new_directory[0].ign = 0;
	new_directory[0].ps = 0;
	new_directory[0].g = 0;
	new_directory[0].avl = 0;
	new_directory[0].base = (KERNEL_PAGE_TABLE_0 >> 12);

	for (int i = 1; i < 1024; ++i) {
		new_directory[i].p = 0;	
	}

	uint32_t next_free_page_task1 = mmu_nextFreeTaskPage();
	uint32_t next_free_page_task2 = mmu_nextFreeTaskPage();

	mmu_mapPage(next_free_page_task1, cr3, next_free_page_task1, ATTR_TASK_PAGE);          // hago identity mapping con las paginas que pedi en el cr3 actual
	mmu_mapPage(next_free_page_task2, cr3, next_free_page_task2, ATTR_TASK_PAGE);          // para poder copiar.


	uint32_t* src = (uint32_t*) NULL;
	uint32_t* dst = (uint32_t*) next_free_page_task1;			// porq lo identity mapee para poder usarlo
	
	if (kernel_or_task == 0) {					// si es kernel solo necesito el codigo del src 10000 o 12000	
		if (index_task < 10) {     
			src = (uint32_t*) CODE_TASK_A;
		}else{ //b
			src = (uint32_t*) CODE_TASK_B;
		}
	} else {									// si soy una tarea q me estoy dividiendo necesito copiar la pila tmbn
		src = (uint32_t*) VIRTUAL_M_TASK_1; // tengo que copiar mi propio codigo+pila	
	}

	for (uint32_t i = 0; i < (PAGE_SIZE*2)/4; ++i){
		*(dst+i)=*(src+i);
	}

	mmu_unmapPage(next_free_page_task1, cr3);			// desmapeo lo q mapee para poder copiar
	mmu_unmapPage(next_free_page_task2, cr3);

	mmu_mapPage(VIRTUAL_M_TASK_1, (uint32_t) new_directory, (uint32_t) next_free_page_task1, ATTR_TASK_PAGE);  // new directory termina siendo cr3 porq justo los ultimos tres van en 0
	mmu_mapPage(VIRTUAL_M_TASK_2, (uint32_t) new_directory, (uint32_t) next_free_page_task2, ATTR_TASK_PAGE);

	return (uint32_t)(new_directory);
	//return (uint32_t)(new_directory||0x3);
}








