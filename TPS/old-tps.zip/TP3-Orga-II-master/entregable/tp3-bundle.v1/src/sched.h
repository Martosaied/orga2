/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  Definicion de funciones del scheduler
*/

#ifndef __SCHED_H__
#define __SCHED_H__

#include "stdint.h"
#include "screen.h"
#include "tss.h"
#include "auxiliares.h"
#include "i386.h"

void sched_init();

int16_t sched_nextTask();

extern uint16_t fruit_map[50][50];

extern uint32_t score_a;
extern uint32_t score_b;
extern uint32_t fruit_quant;
extern uint8_t debug_mode;
extern unsigned int on_libretas;

void kill_actual_task(uint32_t index);
uint32_t nextTurn();

typedef struct str_info_entry {
    uint16_t state;
    uint32_t x;
    uint32_t y;
    uint32_t new_x;
    uint32_t new_y;
    uint16_t counter;
    uint16_t weight;
} __attribute__((__packed__, aligned (8))) info_entry;

extern info_entry info_array[20];
uint32_t INDEX_INFO;

#endif	/* !__SCHED_H__ */
