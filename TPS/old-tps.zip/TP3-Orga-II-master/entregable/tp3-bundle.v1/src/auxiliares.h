/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de estructuras para administrar tareas
*/


#ifndef __AUXILIARES_H__
#define __AUXILIARES_H__

#include "screen.h"
#include "sched.h"
#include "defines.h"

void libretas_init();
void prints(char (*pantalla)[50][160], char* txt, int length);

#endif	/* !__SCHED_H__ */