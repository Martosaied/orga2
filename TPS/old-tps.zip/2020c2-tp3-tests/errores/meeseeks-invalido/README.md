# Test de error: Crear un meeseeks a partir de una dirección inválida

Morty no hace nada.
Tarea Rick trata de crear un Meeseeks usando como código una dirección del kernel.
El juego debe terminar inmediatamente.
Ganador: Morty.
