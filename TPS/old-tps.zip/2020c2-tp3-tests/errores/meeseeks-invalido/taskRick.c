#include "syscall.h"

void task(void) {
  syscall_meeseeks((uint32_t)0x0, 5, 5);

  while (1) {
    __asm volatile("nop");
  }
}
