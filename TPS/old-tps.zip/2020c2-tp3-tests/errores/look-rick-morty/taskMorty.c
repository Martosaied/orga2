#include "stddef.h"
#include "syscall.h"

void task(void) {
  int8_t x = 0;
  int8_t y = 0;

  syscall_look(&x, &y);
  if (x != -1 || y != -1) {
    __builtin_trap();
  }

  while (1) {
    __asm volatile("nop");
  }
}
