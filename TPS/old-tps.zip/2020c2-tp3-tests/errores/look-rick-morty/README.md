# Test de error: Look Rick y Morty

Rick hace Look, y espera que el resultado sea -1.
Morty hace Look, y espera que el resultado sea -1.
Luego de eso, no hacen nada.
El juego tiene que seguir como si los dos jugadores estuvieran quietos.
No debe ocurrir un error.
