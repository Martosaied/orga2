# Test de error: Crear un meeseeks fuera del mapa

Rick no hace nada.
Tarea Morty trata de crear un Meeseeks usando como posición una dirección fuera del mapa.
El juego debe terminar inmediatamente.
Ganador: Rick.
