# Test de error: Mover Rick o Morty

Morty no hace nada.
Tarea Rick trata de moverse. El juego debe finalizar inmediatamente.
Ganador: Morty.
