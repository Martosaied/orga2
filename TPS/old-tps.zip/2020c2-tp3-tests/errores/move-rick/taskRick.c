#include "syscall.h"

void task(void) {
  syscall_move(0, 0);
}
