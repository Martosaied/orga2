Este test verifica que los meeseeks respetan los limites de movimiento.

Morty no hace nada.

Rick crea meeseeks en una columna, cada meeseeks se mueve para la derecha una cantidad de pasos: el meeseek en la fila n se mueve de a n pasos a la derecha.

Se espera que los ultimos 3 meeseeks no se muevan.
7mo meeseek se mueve 2 veces.
El 6to meeseek se mueve 4 veces.
El 5to se mueve 6 veces y así.

NOTA: Poner un breakpoint en la función MOVE para ver que se respeten las restricciones.
