#include "stddef.h"
#include "syscall.h"

void meeseks1_func(void);
void meeseks2_func(void);
void meeseks3_func(void);
void meeseks4_func(void);
void meeseks5_func(void);
void meeseks6_func(void);
void meeseks7_func(void);
void meeseks8_func(void);
void meeseks9_func(void);
void meeseks10_func(void);

void task(void) {
  syscall_meeseeks((uint32_t)&meeseks1_func, 1, 1);
  syscall_meeseeks((uint32_t)&meeseks2_func, 1, 2);
  syscall_meeseeks((uint32_t)&meeseks3_func, 1, 3);
  syscall_meeseeks((uint32_t)&meeseks4_func, 1, 4);
  syscall_meeseeks((uint32_t)&meeseks5_func, 1, 5);
  syscall_meeseeks((uint32_t)&meeseks6_func, 1, 6);
  syscall_meeseeks((uint32_t)&meeseks7_func, 1, 7);
  syscall_meeseeks((uint32_t)&meeseks8_func, 1, 8);
  syscall_meeseeks((uint32_t)&meeseks9_func, 1, 9);
  syscall_meeseeks((uint32_t)&meeseks10_func, 1, 10);

  while (1) {
    __asm volatile("nop");
  }
}

void meeseks1_func(void) {
  while (1) syscall_move(1, 0);
}
void meeseks2_func(void) {
  while (1) syscall_move(2, 0);
}
void meeseks3_func(void) {
  while (1) syscall_move(3, 0);
}
void meeseks4_func(void) {
  while (1) syscall_move(4, 0);
}
void meeseks5_func(void) {
  while (1) syscall_move(5, 0);
}
void meeseks6_func(void) {
  while (1) syscall_move(6, 0);
}
void meeseks7_func(void) {
  while (1) syscall_move(7, 0);
}
void meeseks8_func(void) {
  while (1) syscall_move(8, 0);
}
void meeseks9_func(void) {
  while (1) syscall_move(9, 0);
}
void meeseks10_func(void) {
  while (1) syscall_move(10, 0);
}
