# Test de move: Wrap Around

Rick crea meeseek1 cerca del borde izquierdo de la pantalla.  Morty crea
meeseek2 cerca del borde derecho de la pantalla.  Rick crea meeseek3 cerca del
borde superior de la pantalla.  Morty crea meeseek4 cerca del borde inferior de
la pantalla.

meeseek1 se mueve hacia la izquierda de a 1 casillero, debe aparecer del lado
derecho.

meeseek2 se mueve hacia la derecha de a 1 casillero, debe aparecer del
lado izquierdo.

meeseek3 se mueve hacia la arriba de a 1 casillero, debe
aparecer del lado inferior.

meeseek4 se mueve hacia la abajo de a 1 casillero,
debe aparecer del lado superior.

El juego no debe tirar ningún error.  Es posible que los meeseeks caigan en
alguna semilla. En dicho caso, cambiar las posiciones iniciales.

**IMPORTANTE**: Para realizar este test, poner un breakpoint en la función
move, para ver cada movimiento independientemente.
