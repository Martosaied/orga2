Este test valida el comportamiento de pisar a un meeseeks.

El codigo de rick salta a una funcion mas abajo en el código, que crea un Meeseeks en 1, 1.
Morty crea un Meeseeks en 2, 1 y loopea infinitamente.

El meeseeks de Rick empieza con un monton de nops, luego se mueve hacia la posicion del meeseeks de Morty, pisandolo. Despues de eso, escribe en la direccion virtual del codigo de rick/morty toda basura en los primeros bytes. Si pisa satisfactoriamente al meeseeks de Morty, este va a sobreescribir el codigo de Morty.

Resultado esperado: El juego termina con Rick como ganador, pues morty ejecuta una instrucción invalida.
