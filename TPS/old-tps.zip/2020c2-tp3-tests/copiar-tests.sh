#!/bin/bash

set -e

if [[ -z $1 ]]; then
  echo "Uso: copiar-script.sh «test» «tp»"
  exit 1
fi
if [[ -z $2 ]]; then
  echo "Uso: copiar-script.sh «test» «tp»"
  exit 1
fi

TEST=$1
DST=$2

cp "${1}/taskRick.c" "${DST}/taskRick.c"
cp "${1}/taskMorty.c" "${DST}/taskMorty.c"

cat "${1}/README.md"
