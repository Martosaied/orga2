Este test verifica que el servicio usePortalGun anda correctamente.

Morty crea un meeseeks en la posicion 1, 1, el meeseeks no hace nada.

Rick, luego de 50 ticks de reloj, crea un meeseeks en la posicion 2, 2. El
meeseeks de Rick, llama a la funcion usePortalGun en un ciclo, esperando un par
de ticks de reloj entre cada llamada.

Se espera que el Meeseeks de Morty se teletransporte UNA vez por la pantalla,
y siga vivo (a menos que caiga sobre una mega semilla).

NOTA: Es recomendable poner un breakpoint en la interrupcion de use portal gun
para ver como se transporta.
