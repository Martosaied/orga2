Este test verifica que la syscall look indica la posición de las semillas.

Morty no hace nada.

Rick crea tareas que se mueven de a un paso hacia las semillas, haciendo look entre cada iteración.

El resultado es que las tareas se van moviendo hacia las semillas y eventualmente, Rick gana.
