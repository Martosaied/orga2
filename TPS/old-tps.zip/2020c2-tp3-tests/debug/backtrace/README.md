# Test de error: Crear un meeseeks a partir de una dirección inválida

* Para que las funciones de C armen el stack frame se tiene que cambiar el flag
  `-Og` por `-O0` en los CFLAGS de las tareas del Makefile.

* Se recomienda activar el modo debug por defecto desde el código.

Morty no hace nada.

Tarea Rick crea a un meeseeks que explota.

Lo importante es que antes de explotar el meeseeks hace una cantidad de
llamados recursivos a las funciones A, B y C en el siguiente orden
(A -> B -> C -> A).

Estos llamados se deberían ver reflejados en el backtrace del modo debug.

A medida que pasan los meeseeks se va a ir haciendo un llamado menos a estas
funciones.

Empezando desde la cantidad que contenga la variable MAX y decrementando de a un
llamado por invocación de meeseeks.   

Se debería ir viendo como la primer dirección impresa por el backtrace
desaparece en cada interrupción del debugger.

El juego no debería explotar nunca.
