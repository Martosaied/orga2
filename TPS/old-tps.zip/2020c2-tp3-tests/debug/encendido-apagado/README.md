# Test de error: Chequear el funcionamiento del toggle del debugger

Morty no hace nada.
Tarea Rick va a crear 3 meeseeks en la parte superior izquierda de la pantalla en periodos de tiempo espaciados (Para alterar el tiempo cambiar el valor de la variable WAIT_TIME). Estos meeseeks también van a esperar un tiempito y van a explotar. Este tiempo está pensado para que puedas ir cambiando el estado del debugger.
Lo que deberías ver cuando el debugger está apagado es que los 3 meeseeks van titilando en orden de arriba hacia abajo. Cuando lo prendés debería saltarte la pantalla de debugger cada vez que un meeseeks desaparece.
El juego debería no terminar nunca.
