Este test verifica que las tareas Rick y Morty comparten espacio de memoria.

Morty no hace nada.

Rick crea una tarea meeseeks, lee algo al principio de su segunda pagina. La
tarea apenas comienza escribe algo al principio de su segunda pagina. Si Rick no
lee el valor escrito por la tarea, entonces explota.

Resultado esperado: El juego no termina. Si hay un error puede deberse a que o
bien la memoria no se comparte, o bien el scheduler no pone a la tarea meeseeks
antes de que se ejecute el código de rick de nuevo. Tambien puede ser que el
meeseeks no se haya podido crear de forma exitosa. En ese caso, reposicionarlo.
