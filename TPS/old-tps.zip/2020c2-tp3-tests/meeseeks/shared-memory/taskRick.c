#include "stddef.h"
#include "syscall.h"

void meeseks1_func(void);

void task(void) {

  uint32_t ret = 0;
  ret = syscall_meeseeks((uint32_t)&meeseks1_func, 1, 1);
  if (ret == 0) {
    // No se pudo crear el meeseek, corregir el test.
    __builtin_trap();
  }

  uint32_t* value = (uint32_t*) (ret + 0x1000);

  // Si el scheduler esta mal, es posible que no se ejecute
  // la tarea meeseeks antes que esta. En ese caso,
  // descomentar este codigo.
  /*
  int8_t x, y;
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  */

  if (value[0] != 0xdeadbeef) {
    __builtin_trap();
  }

  while (1) {
    __asm volatile("nop");
  }
}

void meeseks1_func(void) {
  int x = 0x0;
  // x vive en el stack. Tomamos la direccion y vamos al principio de la segunda pagina.
  uint32_t xdir = ((uint32_t) &x) & ~0xFFF;

  uint32_t* value = (uint32_t*) xdir;
  value[0] = 0xdeadbeef;
  while (1) {
    __asm volatile("nop");
  }
}
