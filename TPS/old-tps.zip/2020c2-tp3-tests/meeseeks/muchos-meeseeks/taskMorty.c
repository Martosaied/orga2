#include "stddef.h"
#include "syscall.h"
#include "i386.h"

void meeseeks_quieto_func(void);

void task(void) {
  for (int row = 0; row < 40; row++) {
    for (int col = 0; col < 80; col++) {
      uint32_t res = 0;
      while (res == 0) {
        res = syscall_meeseeks((uint32_t)&meeseeks_quieto_func, col, row);
      }
    }
  }

  while (1) {
    __asm volatile("nop");
  }
}

void meeseeks_quieto_func(void) {
  int8_t x, y;
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  syscall_look(&x, &y);
  __builtin_trap();
}
