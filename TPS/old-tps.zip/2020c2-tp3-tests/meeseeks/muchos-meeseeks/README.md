Este test verifica que se puedan crear más de 10 meeseeks.

Rick no hace nada. Morty crea muchos meeseeks que esperan un par de ciclos
haciendo look y luego terminan. Si un meeseeks no se pudo crear, Morty vuelve a
intentar.

El resultado es que Morty va creando meeseeks por toda la pantalla, y
eventualmente terminan. Se ve como si fuese una viborita yendo de izquierda a
derecha, de arriba hacia abajo.
