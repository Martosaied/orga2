Este test verifica que se puedan crear hasta 10 meeseeks.

Rick no hace nada.  Morty crea 10 meeseeks que se quedan quietos, y empieza a
crear meeseeks que se mueven.

El resultado debe ser que ninguno de los meeseeks se mueve, ya que los 10
meeseeks quietos siguen quietos.

NOTA: Es posible que la posición en donde se crean los meeseeks tenga una
megasemilla. Poner un breakpoint en la función de capturar para asegurarse que
esto no ocurre, y si es así, cambiar la posición donde se crean los meeseeks
