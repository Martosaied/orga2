#include "stddef.h"
#include "syscall.h"
#include "i386.h"

void meeseks1_func(void);

void task(void) {
  for (int i = 0; i < 80; i++) {
    syscall_meeseeks((uint32_t)&meeseks1_func, i, 5);
  }
  while (1) {
    __asm volatile("nop");
  }
}

void meeseks1_func(void) {
  uint8_t* kernel_free_area_start = (uint8_t*) 0x100000;
  int i = 0;
  while (1) {
    kernel_free_area_start[i] = 0x0;
    i++;
  }
}
