Este test verifica que al «reiniciar» meeseeks, estos se ejecutan en nivel 3.
Un error que puede ocurrir es que se intente reusar una TSS pero no se reinicien
sus valores de forma correcta, causando que la nueva tarea se ejecute en nivel
3.

Morty no hace nada.

Rick crea Meeseeks que tratan de escribir en el area libre
de memoria.

El resultado esperado es que no ocurra nada, Rick está creando Mr Meeseeks que
deberian morir apenas arrancan, y nunca ejecutarse en nivel 0.
